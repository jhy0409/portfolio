﻿using System.Windows.Forms;

namespace EmartIbgu_Kiosk
{
    public partial class _3rd_Location : UserControl
    {
        public _3rd_Location()
        {
            InitializeComponent();
        }
    }
}
